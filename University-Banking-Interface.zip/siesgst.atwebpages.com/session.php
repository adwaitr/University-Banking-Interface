<?php
   include('config.php');
   session_start();
   
   $user_check = $_SESSION['username'];
   $code = $_SESSION['username'];
   
   $ses = mysqli_query($db,"select Fname from reg where prn = '$user_check' "); 
   $use = mysqli_fetch_assoc($ses);
   if($use['Fname'] != "NA"){
   $user_check=$use['Fname'];
   }
   
   if(!isset($_SESSION['username'])){
      header("location: ./login.php");
      die();
   }
?>