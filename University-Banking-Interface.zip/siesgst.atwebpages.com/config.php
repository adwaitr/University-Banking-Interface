<?php
   define('DB_SERVER', 'fdb26.runhosting.com');
   define('DB_USERNAME', '3084519_project');
   define('DB_PASSWORD', 'thane607');
   define('DB_DATABASE', '3084519_project');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>