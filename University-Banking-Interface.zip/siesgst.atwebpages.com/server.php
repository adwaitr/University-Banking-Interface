<?php
session_start();

// initializing variables
$username1 = "";
$email    = "";
$username = "";

// REGISTER USER
if (isset($_POST['reg_user'])) {

 include_once 'config.php'; 
  // receive all input values from the form
 $username1  =  $_POST['username1'];
 $email      =  $_POST['email'];
 $password_1 =  $_POST['password_1'];
 $password_2 =  $_POST['password_2'];
 if(empty($username1) || empty($email) ||empty($password_1) || empty($password_2)) {
  header("./prj-login.php?signup=empty");
  exit();
}
else
{
  if(!filter_var($email,FILTER_VALIDATE_EMAIL))
  {
    header("Location: ./prj-login.php?signup=email");
    exit();
  }
  elseif ($password_1 != $password_2) {
    header("Location: ./prj-login.php?signup=pass");
    exit();
  }
  else
  {
    // first check the database to make sure 
  // a user does not already exist with the same username and/or email
    $user_check_query = "SELECT * FROM reg WHERE prn='$username1' OR email='$email'";
    $result = mysqli_query($db, $user_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) 
    { // if user exists
      if ($user['prn'] === $username1) 
      {
        header("Location: ./prj-login.php?signup=uexist");
        exit();
      }

      if ($user['email'] === $email) 
      {
        header("Location: ./prj-login.php?signup=eexist");
        exit();
      }
    }
  }
}


  // Finally, register user if there are no errors in the form
  if (!$user) {
    $password1 = md5($password_1);//encrypt the password before saving in the database
    
    $create="CREATE TABLE `3084519_project`.`$username1` ( `id` INT(200) NOT NULL AUTO_INCREMENT , `datetime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP , `deposit` INT(200) NOT NULL , `withdrawal` INT(200) NOT NULL , `total` INT(200) NOT NULL , PRIMARY KEY (`id`)) ENGINE = MyISAM;";
    mysqli_query($db,$create);

    $query = "INSERT INTO reg (prn, email, password,Fname,Lname,phone,lang) VALUES('$username1','$email','$password1','NA','NA','0','NA')";
    mysqli_query($db, $query);
    
    $query = "INSERT INTO $username1 (deposit, withdrawal, total) VALUES('1000','0','1000')";
    mysqli_query($db, $query);

    
    header('location: ./prj-login.php?signup=success');
}
}

if (isset($_POST['login_user'])) {
  include_once 'config.php'; 
  $username = $_POST['username'];
  $password = $_POST['password'];


    $password = md5($password);
    $query = "SELECT * FROM reg WHERE prn='$username' AND password='$password'";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['username'] = $username;
      $_SESSION['success'] = "You are now logged in";
      header('location: ./prj-userhome.php');
    }else {
        header('location: ./prj-login.php?signup=not');
    }
  
}


?>
