<?php
   include('session.php');
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <title>SIESGST Bank</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="contactus.js"></script>
  <style type="text/css">
    .jumbotron{
       box-shadow: 0 0 15px 9px #00000096;
      margin-top: 48px;
      background-image: url('https://images.unsplash.com/photo-1531685250784-7569952593d2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1567&q=80');
      background-size: cover;
      background-repeat: no-repeat;
      padding: 30px;
      border-radius: 20px;
    }
    #imgg{
      box-shadow: 0 0 8px 5px #00000096;
      margin-right: 20px;
      float: right;
      border-radius: 5px;
    }
    /* width */
::-webkit-scrollbar {
  width: 20px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0.5px 5px #0333; 
  border-radius: 8px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: lightgrey; 
  border-radius: 8px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: lightblue; 
}
    .nav-link{
      margin-left: 2px;
    }
    .topnav {
      box-shadow: 0 0 8px 5px #00000096;
      overflow: hidden;
      background-color: rgba(236, 48, 20, 0.9);
      border-radius: 2px;
    }
    /* width */
::-webkit-scrollbar {
  width: 20px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0.5px 5px #0333; 
  border-radius: 8px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: lightgrey; 
  border-radius: 8px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: lightblue; 
}
    .topnav a {
      float: left;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 14px;
    }
    .topnav a:hover {
      transition: all 0.4s ease;
      background-color: #ffffff;
      color: black;transform: scale(1.1);
    }
  .page-footer a{
      width:100%;
      float: left;
      color: #f2f2f2;
      text-align: left;
      font-size: 14px;
    }
    .page-footer a:hover {
      transition: all 0.4s ease;
      background-color: #ffffff;
      color: black;transform: scale(1.1);
    }
  .page-footer  {
      box-shadow: 0 0 15px 9px #00000096;
      margin-top: 60px; 
      overflow : hidden;
      display: block;
      background-color: rgba(236, 48, 20, 0.9);
      border-radius: 2px;
    }
    body{
        background-size: cover; 
    }
    span{
        font-size:15px;
    }
    .box{
      padding:60px 0px;
    }
    .box-part{
        background:#FFF;
        border-radius:0;
        padding:60px 10px;
        margin:30px 0px;
        border-radius: 60px;
    }
    .text{
        text-align: center;
        margin:20px 0px;
    }
    .fa{
         color:#4183D7;
    }
    #txt{
      color: black;
    }
    #xyz{
      border-radius: 37px;
      background-color: lightblue;
      overflow: hidden;
    }
    #ctc{
      border-radius: 7px;
      padding: 7px;
    }
    .form-group{
      margin-left: 20px;
      border-radius: 15px;
    }
     #sch{
      float: right;
      margin-top: 7px;
      margin-right: 9px;
      box-shadow: 0 0 .5px .5px #00000096;
    }
    #mi{
      font-size: 2.5px;
      color: white;
    }
  </style>
</head>
<body background="prj-body-bg.jpg"> 
<div class="bg-img">
  <div class="full-size-container">
    <div class="topnav" style="display: block;">
      <a href="prj-home.html">SIES BANK</a>
      <a href="http://www.siesgst.edu.in/">SIESGST Portal</a>
      <button type="submit" id="sch"><i class="fa fa-search"></i></button>
      <input type="text" placeholder="Search" name="search" id="sch" style="border-radius: 8px;" >
    </div>
  </div>
</div>
<div class="box" >
    <div class="container">
      <div class="jumbotron">
        <img src="prj-gst-logo.png" id="imgg" >
        <div class="title">
              <h3 id="txt"> Deposits History </h3>
            </div> <br>
            <br><br>
        <hr>
        <div class="container">
        <?php
$ttt = mysqli_query($db,"SELECT * FROM $code ORDER BY id DESC ");


?>
<table class="table table-hover table-bordered">
<thead class="thead-dark">
      <tr>
        <th>SR No</th>
        <th>Datetime</th>
        <th>Deposits</th>
      </tr>
    </thead>
    <tbody>
<?php
while($row = mysqli_fetch_assoc($ttt))
        {
        if($row['deposit'] != 0){
    echo "<tr>";
    echo "<td>" . $row['id'] ."</td>";
    echo "<td>" . $row['datetime'] . "</td>";
    echo "<td>" . $row['deposit'] . "</td>";
    echo "</tr>";
        }}
?>
</tbody>
</table>
</div> 
            </div>
        </div>
            </div>
<footer class="page-footer font-small stylish-color-dark " id="footer" >
  <div class="full-size-container">
      <hr class="footer w-100 d-md-none">
      <div class="col-md-2"><br>
        <h5 class="font-weight-bold text-uppercase mt-3 mb-4"> Navigate</h5>
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="prj-privacy.html"> Privacy Policy </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="prj-about.html"> About Us </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="prj-contact.html"> Contact Us </a>
      </li>
    </ul>
      </div>
  </div>
</footer>
</body>
</html>
