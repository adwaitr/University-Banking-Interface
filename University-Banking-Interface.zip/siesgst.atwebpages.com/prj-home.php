
<!DOCTYPE html>
<html lang="en" >
<head>
  <title>SIESGST Bank</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">
  	body{ 
  		background-size: cover;
  	}
  	.jumbotron{
      box-shadow: 0 0 15px 9px #00000096;
  		margin-top: 130px;
  		background-image: url('https://images.unsplash.com/photo-1531685250784-7569952593d2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1567&q=80');
  		background-size: cover;
  		background-repeat: no-repeat;	
    }
  	#imgg{
		  border-radius: 3px;
  	}
    .nav-link{
      margin-left: 2px;
    }
    .row{
      float: right;
    }
    .topnav {
      box-shadow: 0 0 15px 9px #00000096;
      overflow: hidden;
      background-color: rgba(236, 48, 20, 0.9);
    }
    .topnav a {
      float: left;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 14px;
    }
    .topnav a:hover {
      transition: all 0.4s ease;
      background-color: #ffffff;
      color: black;transform: scale(1.1);
    }
	.page-footer a{
	  width:100%;
      float: left;
      color: #f2f2f2;
      text-align: left;
      font-size: 14px;
    }
    .page-footer a:hover {
      transition: all .4s ease;
      background-color: #ffffff;
      color: black;transform: scale(1.1);
    }
    /* width */
::-webkit-scrollbar {
  width: 20px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0.5px 5px #0333; 
  border-radius: 8px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: lightgrey; 
  border-radius: 8px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: lightblue; 
}
	.page-footer  {
      margin-top: 40px;
      box-shadow: 0 0 15px 9px #00000096;
      overflow: hidden;
      background-color: rgba(236, 48, 20, 0.9);
    }
     #sch{
      float: right;
      margin-top: 7px;
      margin-right: 9px;
      box-shadow: 0 0 .5px .5px #00000096;
    }
   @media only screen and (max-width: 600px){
   .row{
      float: left;
   }
 </style>
</head>
<body background="prj-body-bg.jpg" >  
<div class="bg-img">
  <div class="full-size-container">
    <div class="topnav " style="display: block;">
      <a href="prj-home.php">SIES BANK</a>
                      <script async src="https://cse.google.com/cse.js?cx=011206658419054800993:1mitngfrgxb"></script>
<div class="gcse-search"></div>
    </div>
  </div>
</div>
<div class="jumbotron text-left">
  <div class="row" style="margin-left:2px;">
    <ul class="nav">
        <li class="nav-item" >
          <a class="nav-link btn btn-danger" style="box-shadow:0 0 .1px .1px #00000096; " href="prj-login.php" >Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-outline-success " style="box-shadow:0 0 .1px .1px #00000096; " href="prj-login.php">Create Account</a>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-warning "  style="box-shadow:0 0 .1px .1px #00000096; " href="prj-about.html">About</a>
        </li>
    </ul>
  </div>
  <h1 id="int" class="text-monospace">SIESGST Banking Interface </h1>
  <img src="prj-gst-logo.png" id="imgg"style="box-shadow: 0 0 8px 5px #00000096; " >

  <p>
    <h5 class="text-monospace">Site Visits</h5>
    <a href="https://smallseotools.com/visitor-hit-counter/" target="_blank" title="Visitor Hit Counter">
      <img src="https://smallseotools.com/counterDisplay?code=d24a9d857d253cefb471e986d5be9ed9&style=0013&pad=5&type=page&initCount=1"  title="Visitor Hit Counter" Alt="Visitor Hit Counter" border="1" style="box-shadow:0 0 .5px .5px #00000096; ">
    </a>
  </p>
</div>
<footer class="page-footer stylish-color-dark " >
  <div class="full-size-container">
      <hr class="clearfix w-100 d-md-none">
      <div class="col-md-2">
        <h5 class="font-weight-bold text-uppercase mt-3 mb-4"> Navigate</h5>
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link" href="prj-privacy.html" title="Shows Company Statement"> Privacy Policy </a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="prj-about.html" title="Shows Company's Mission"> About Us </a>
			</li>
			<li class="nav-item ">
				<a class="nav-link" href="prj-contact.html" title="Feedback"> Contact Us </a>
			</li>
		</ul>
    </div>
  </div>
</div>
</footer>
</body>
</html>
