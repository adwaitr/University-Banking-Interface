<?php

include("config.php");
include("session.php");

$quuu ="SELECT * FROM reg WHERE prn='$code'";
$res = mysqli_query($db, $quuu);
$val = mysqli_fetch_assoc($res);


if (isset($_POST['save_user'])) {

 include_once 'config.php'; 
  // receive all input values from the form
$Fname  =  $_POST['fname'];
$Lname  =  $_POST['lname'];
$phone  =  $_POST['ph'];
$email  =  $_POST['email'];
$dob    =  strtotime($_POST['dob']);
$dob    = date('Y-m-d', $dob);
$lang   =  $_POST['lan'];

 if(empty($Fname) || empty($email) ||empty($Lname) || empty($phone) || empty($dob) || empty($lang)) {
  header("./prj-acset.php?signup=empty");
  exit();
}
elseif($Fname == $val['Fname'] && $Lname == $val['Lname'] && $phone == $val['phone'] && $email == $val['email'] && $dob == $val['dob'] && $lang == $val['lang'])
{ header("Location: ./prj-acset.php?signup=notrequired");
  exit();
}
else{
  if(!filter_var($email,FILTER_VALIDATE_EMAIL))
  {
    header("Location: ./prj-acset.php?signup=email");
    exit();
  }
  elseif (!preg_match("/^[6-9]\d{9}$/", $phone)) {
    header("Location: ./prj-acset.php?signup=ph");
    exit();
  }
  elseif (!preg_match("/^([a-zA-Z' ]+)$/",$Fname)) {
    header("Location: ./prj-acset.php?signup=fn");
    exit();
  }
  elseif (!preg_match("/^([a-zA-Z' ]+)$/",$Lname)) {
    header("Location: ./prj-acset.php?signup=ln");
    exit();
  }
  else{
    $query ="UPDATE reg SET email = '$email', Fname = '$Fname',Lname = '$Lname', phone = '".$phone."', dob='".$dob."', lang='$lang' WHERE prn='$code';";
    mysqli_query($db, $query);
    header('location: ./prj-acset.php?signup=success');
  }
}
}
?>