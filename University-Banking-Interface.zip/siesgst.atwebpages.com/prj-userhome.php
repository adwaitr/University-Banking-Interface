<?php
   include('session.php');
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <title>SIESGST Bank</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="contactus.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">
    .jumbotron{
       box-shadow: 0 0 15px 9px #00000096;
      margin-top: 48px;
      background-image: url('https://images.unsplash.com/photo-1531685250784-7569952593d2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1567&q=80');
      background-size: cover;
      background-repeat: no-repeat;
      padding: 30px;
      border-radius: 20px;
    }
    #imgg{
    margin-right: 20px;
        float: right;
       border-radius: 5px;
    }
    .nav-link{
      margin-left: 2px;
    }
    .topnav {

      overflow: hidden;
      background-color: rgba(236, 48, 20, 0.9);
      border-radius: 2px;
      box-shadow: 0 0 15px 9px #00000096;
    }
    .topnav a{
      float: left;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 14px;
    }
    .topnav a:hover {
      transition: all 0.4s ease;
      transition: all 0.4s ease;
      background-color: #ffffff;
      color: black;transform: scale(1.1);
    }
    .page-footer a{
      width:100%;
      float: left;
      color: #f2f2f2;
      text-align: left;
      font-size: 14px;
    }
    .page-footer a:hover {
      transition: all 0.4s ease;
      background-color: #ffffff;
      color: black;transform: scale(1.1);
    }
    .page-footer  {
      box-shadow: 0 0 15px 9px #00000096;
      margin-top: 60px; 
      overflow : hidden;
      display: block;
      background-color: rgba(236, 48, 20, 0.9);
      border-radius: 2px;
    }
    body{
        background-size: cover; 
    }
    span{
        font-size:15px;
    }
    .box{
        padding:60px 0px;
    }
    .box-part{
        background:#FFF;
        border-radius:0;
        padding:60px 10px;
        margin:30px 0px;
        border-radius: 60px;
    }
    .text{
        text-align: center;
        margin:20px 0px;
    }
    .fa{
         color:#4183D7;
    }
    #txt{
      color: black;
    }
    #xyz{
      border-radius: 37px;
      background-color: lightblue;
      overflow: hidden;
      box-shadow: 0 0 .5px .5px #00000096;
    }
    #ctc{
      border-radius: 7px;
      padding: 7px;
    }
    .form-group{
      margin-left: 20px;
      border-radius: 15px;
    }
    img{
      box-shadow: 0 0 8px 5px #00000096;
    }
    #sch{
      float: right;
      margin-top: 7px;
      margin-right: 9px;
      box-shadow: 0 0 .5px .5px #00000096;
    }
    /* width */
::-webkit-scrollbar {
  width: 20px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0.5px 5px #0333; 
  border-radius: 8px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: lightgrey; 
  border-radius: 8px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: lightblue; 
}

#user{text-align:right;float:right;}

@media only screen and (max-width:650px){
#user{text-align:left;float:left;
}
}
  </style>
</head>
<body background="prj-body-bg.jpg">  
<div class="bg-img">
  <div class="full-size-container">
    <div class="topnav" style="display: block;">
      <a href="prj-home.php">SIES BANK</a>
                     <script async src="https://cse.google.com/cse.js?cx=011206658419054800993:1mitngfrgxb"></script>
<div class="gcse-search"></div>
      <a href="prj-acset.php" >Settings</a>
      <a href="logout.php" style="color: black;">Logout</a>

    </div>
  </div>
</div>
<div class="box" >
    <div class="container">
      <div class="jumbotron">
        
        <div class="title">
                 <h2 style="text-align:left;float:left;margin-right:30px;">Dashboard</h2> 
                <h3  id="user">Welcome <?php print($user_check); ?></h3> 
                <hr style="clear:both;"/>
           
        </div> <br>
            <div class="container" id="xyz"> <br>
                    <h3 style="margin-left: 15px;"> <b> Your Account </b> </h3> <br>
<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading text-center"><h6><a href="prj-bal.php">Account balance</a></h6></div> 
        <div class="panel-body"><img src="prj-bal.jpeg"  style="width:100%" alt="Image"></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading text-center"><h6><a href="prj-with.php">Withdrawals</a></h6></div>
                <div class="panel-body"> <img src="prj-bill.jpg"   style="width:100%" alt="Image" height="185"></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-success">
        <div class="panel-heading text-center"><h6><a href="prj-dep.php">Deposits</a></h6></div>
        <div class="panel-body"><img src="prj-mon.jpg"  style="width:100%" alt="Image" height="185"></div>
      </div>
    </div>
  </div>
</div><br>
<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
       <div class="panel-heading text-center"><h6><a href="prj-der.php">Money Transfer</a></h6></div>
        <div class="panel-body"><img src="prj-der.jpg"  style="width:100%" alt="Image" height="185"></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading text-center"><h6><a href="prj-hist.php">Account History</a></h6></div>
        <div class="panel-body"><img src="prj-his.jpg"  style="width:100%" alt="Image" height="185"></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading text-center"><h6><a href="prj-report.html">Monthly Report</a></h6></div>
        <div class="panel-body"><img src="prj-report.jpg"  style="width:100%" alt="Image" height="185"></div>
      </div>
    </div>
  </div>
</div><br><br>
        </div>
    </div>
  </div>
</div>
<?php
if(strval($use['Fname']) == "NA"){
        echo '<script type="text/javascript">';
        echo 'var isBoss = confirm("Profile is incomplete ! \n Click OK to complete profile.");';
        echo 'if(isBoss == true) {';
        echo 'window.location = "./prj-acset.php";';
        echo '}else{alert("Few Steps away from Completion ! ");}';
        echo '</script>';
        }
        ?>
<footer class="page-footer" id="footer" >
  <div class="full-size-container">
      <hr class="footer w-100 d-md-none">
      <div class="col-md-2"><br>
        <h5 class="font-weight-bold text-uppercase mt-3 mb-4"> Navigate</h5>
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="prj-privacy.html"> Privacy Policy </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="prj-about.html"> About Us </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="prj-contact.html"> Contact Us </a>
      </li>
    </ul>
      </div>
  </div>
</footer>
</body>
</html>
