<?php
include("set.php");
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <title>SIESGST Bank</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="contactus.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">
    .jumbotron{
     box-shadow: 0 0 15px 9px #00000096;
     margin-top: 48px;
     background-image: url('https://images.unsplash.com/photo-1531685250784-7569952593d2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1567&q=80');
     background-size: cover;
     background-repeat: no-repeat;
     padding: 30px;
     border-radius: 20px;
   }
   #imgg{
    margin-right: 20px;
    float: right;
    border-radius: 5px;
  }
  .nav-link{
    margin-left: 2px;
  }
  .topnav {
    overflow: hidden;
    background-color: rgba(236, 48, 20, 0.9);
    border-radius: 2px;
    box-shadow: 0 0 15px 9px #00000096;
  }
  .topnav a{
    float: left;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 14px;
  }
  .topnav a:hover {
    transition: all 0.4s ease;
    background-color: #ffffff;
    color: black;
    transform: scale(1.1);
  }
  .page-footer a{
    width:100%;
    float: left;
    color: #f2f2f2;
    text-align: left;
    font-size: 14px;
  }
  .page-footer a:hover {
    transition: all 0.4s ease;
    background-color: #ffffff;
    color: black;
    transform: scale(1.1);
  }
  .page-footer  {
    box-shadow: 0 0 15px 9px #00000096;
    margin-top: 60px; 
    overflow : hidden;
    display: block;
    background-color: rgba(236, 48, 20, 0.9);
    border-radius: 2px;
  }
  body{
    background-size: cover; 
  }
  span{
    font-size:15px;
  }
  .box{
    padding:60px 0px;
  }
  .box-part{
    background:#FFF;
    border-radius:0;
    padding:60px 10px;
    margin:30px 0px;
    border-radius: 60px;
  }
  .text{
    text-align: center;
    margin:20px 0px;
  }
  .fa{
   color:#4183D7;
 }
 #txt{
  color: black;
}
#xyz{
  border-radius: 37px;
  background-color: lightblue;
  overflow: hidden;
  box-shadow: 0 0 .5px .5px #00000096;
}
#ctc{
  border-radius: 7px;
  padding: 7px;
}
.form-group{
  margin-left: 20px;
  border-radius: 15px;
}
img{
  box-shadow: 0 0 8px 5px #00000096;
}
#sch{
  float: right;
  margin-top: 7px;
  margin-right: 9px;
  box-shadow: 0 0 .5px .5px #00000096;
}
label {
  display: block;
  font-weight: bold;
}
select, textarea {
  width:100%;
}
form.account-settings {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 2vw;
}
.input--wide {
  grid-column: 1 / 3;
}
#ac{
  width: 100%
}
#ac:hover {
  background-image: url(prj-report.jpg); 
  transition: all 0.2s ease;
  background-color: lightblue;
}
#bdy{
  width: 100%;
  box-shadow: 0 0 .5px .5px #00000096;
}
#bdy:hover{
 background-image: url(prj-report.jpg); 
 transition: all 0.2s ease;
 background-color: lightblue;
}
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: lightgrey;
  color: black;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
  box-shadow: 0 0 .5px .5px #00000096;
}
#myBtn:hover {
  transition: all 0.2s ease;
  background-color: lightblue;
}
select:hover {
  background-image: url(prj-report.jpg); 
  transition: all 0.2s ease;
  background-color: lightblue;
}
/* width */
::-webkit-scrollbar {
  width: 20px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0.5px 5px #0333; 
  border-radius: 8px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: lightgrey; 
  border-radius: 8px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: lightblue; 
}
#sv{
  float:center;
}
#snackbar {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background-color: lightblue; /* Blue background color */
  color: black; /* blck text color */
  text-align: center; /* Centered text */
  border-radius: 5px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 1; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  bottom: 30px; /* 30px from the bottom */
  box-shadow: 0 0 .5px .5px #00000096;
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#snackbar.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}
  
.sel {
box-shadow: 0 0 .5px .5px #00000096;

}


</style>
</head>
<body background="prj-body-bg.jpg">  
  <div class="bg-img">
    <div class="full-size-container">
      <div class="topnav" style="display: block;">
        <a href="prj-home.php">SIES BANK</a>
        <a href="http://www.siesgst.edu.in/">SIESGST Portal</a>
        <script async src="https://cse.google.com/cse.js?cx=011206658419054800993:1mitngfrgxb"></script>
<div class="gcse-search"></div>
        <a href="logout.php" style="color: black;">Logout</a>
        <a href="prj-userhome.php" >Dashboard</a>

      </div>
    </div>
  </div>
  <div class="box" >
    <div class="container">
      <div class="jumbotron">
        <img src="prj-gst-logo.png" id="imgg" >
        <div class="title">
          <h3 id="txt"> Account Settings</h3>
          <h4> Version : 1.0 </h4>
        </div> <br>
        <div class="container" id="xyz"> <br>
          <h3 style="margin-left: 15px;"> User Profile</h3> <br>

          <form class="form-horizontal" method="POST">
            <div class="row"> <div class="form-group">
              <label for="firstname">First Name</label>
              <input type="text" class="sel" name="fname" id="ac"  style="box-shadow: 0 0 .5px .5px #00000096;" value="<?php print($val['Fname']); ?>">
            </div> </div>
            <div class="row"> <div class="form-group">
              <label for="firstname">Last Name</label>
              <input type="text" class="sel" name="lname" id="ac"  style="box-shadow: 0 0 .5px .5px #00000096;"  value="<?php print($val['Lname']); ?>">
            </div></div>
            <div class="row"><div class="form-group">
              <label for="phone">Phone</label>
              <input type="text" class="sel" name="ph" id="ac"  style="box-shadow: 0 0 .5px .5px #00000096;" value="<?php print($val['phone']); ?>">
            </div></div>
            <div class="row "><div class="form-group">
              <label for="email">Email</label>
              <input type="text" class="sel" name="email" id="ac" style="box-shadow: 0 0 .5px .5px #00000096;margin-right:5px;" value="<?php print($val['email']); ?>">
            </div></div>
            <div class="form-group"> <div class="row input--wide">
              <label for="firstname">Birthdate</label>
              <input type="date" name="dob" id="bdy"  style="box-shadow: 0 0 .5px .5px #00000096;margin-right:10px;" value="<?php echo strftime('%Y-%m-%d', strtotime($val['dob'])); ?>">
            </div>
            <div class="row">
              <label for="Language">Language</label> 
              <select id="ac" name="lan" class="sel" style="box-shadow: 0 0 .5px .5px #00000096;margin-right:10px;" >
                <option value="English" <?php if($val['lang']=="English") echo selected;?>>English</option>
                <option value="Hindi" <?php if($val['lang']=="Hindi") echo selected;?>>Hindi</option>
                <option value="Tamil" <?php if($val['lang']=="Tamil") echo selected;?>>Tamil</option>
                <option value="Marathi" <?php if($val['lang']=="Marathi") echo selected;?>>Marathi</option>
                <option value="Parseltongue" <?php if($val['lang']=="Parseltongue") echo selected;?>>Parseltongue</option>
                <option value="Konkani" <?php if($val['lang']=="Konkani") echo selected;?>>konkani</option>
                <option value="Dothraki" <?php if($val['lang']=="Dothraki") echo selected;?>>Dothraki</option>
              </select> 
            </div></div>
           <br> <button id="sv" type="submit" class="btn btn-success" style="box-shadow: 0 0 .8px .8px #00000096;" name="save_user" title="save changes" >Save Changes</button><br> <br> 
                </form>
        <div id="snackbar"> Changes saved !</div>
    </div>
  </div>
  <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
  <script>
    window.onscroll = function() {scrollFunction()};

    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
      } else {
        document.getElementById("myBtn").style.display = "none";
      }
    }
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
  </script>
  <footer class="page-footer" id="footer" >
    <div class="full-size-container">
      <hr class="footer w-100 d-md-none">
      <div class="col-md-2"><br>
        <h5 class="font-weight-bold text-uppercase mt-3 mb-4"> Navigate</h5>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="prj-privacy.html"> Privacy Policy </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="prj-about.html"> About Us </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="prj-contact.html"> Contact Us </a>
          </li>
        </ul>
      </div>
    </div>
  </footer>
      <?php

      if (!isset($_GET['signup'])) {
        exit();
      }
      else
      {

        $check = $_GET['signup'];
        if ($check == "empty") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Dont Leave Fields empty")'; 
          echo '</script>';
          exit();
        }
        if ($check == "email") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Email is invalid")'; 
          echo '</script>';
          exit();
        }
        if ($check == "notrequired") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("NO changes has been done")'; 
          echo '</script>';
          exit();
        }
        if ($check == "ph") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Enter Valid Phone Number")'; 
          echo '</script>';
          exit();
        }
        if ($check == "fn") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Enter Valid First Name")'; 
          echo '</script>';
          exit();
        }
        if ($check == "ln") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Enter Valid Last Name")'; 
          echo '</script>';
          exit();
        }
        if($check == "success"){
        echo '<script>';
        echo 'var x = document.getElementById("snackbar");';
        echo 'x.className = "show";';
        echo 'setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);';
        echo '</script>';
      } 
      }
      ?>
</body>
</html>
