<?php
   session_start();
   
   if(session_destroy()) {
      header("Location: prj-home.php");
   }
?>