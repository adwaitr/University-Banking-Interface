<?php
include('der.php');
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <title>SIESGST Bank</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="contactus.js"></script>
  <style type="text/css">
    .jumbotron{
     box-shadow: 0 0 15px 9px #00000096;
     margin-top: 48px;
     background-image: url('https://images.unsplash.com/photo-1531685250784-7569952593d2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1567&q=80');
     background-size: cover;
     background-repeat: no-repeat;
     padding: 30px;
     border-radius: 20px;
   }
   #imgg{
    box-shadow: 0 0 8px 5px #00000096;
    margin-right: 20px;
    float: right;
    border-radius: 5px;
  }
  .nav-link{
    margin-left: 2px;
  }
  .topnav {
   box-shadow: 0 0 15px 9px #00000096;
   overflow: hidden;
   background-color: rgba(236, 48, 20, 0.9);
   border-radius: 2px;
 }
 .topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 14px;
}
.topnav a:hover {
  transition: all 0.4s ease;
  background-color: #ffffff;
  color: black;transform: scale(1.1);
}
/* width */
::-webkit-scrollbar {
  width: 20px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0.5px 5px #0333; 
  border-radius: 8px;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: lightgrey; 
  border-radius: 8px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: lightblue; 
}
.page-footer a{
  width:100%;
  float: left;
  color: #f2f2f2;
  text-align: left;
  font-size: 14px;
}
.page-footer a:hover { 
  transition: all 0.4s ease;
  box-shadow: 0 0 15px 9px #00000096;
  background-color: #ffffff;
  color: black;transform: scale(1.1);
}
.page-footer  {
  margin-top: 60px; 
  overflow : hidden;
  display: block;
  background-color: rgba(236, 48, 20, 0.9);
  border-radius: 2px;
}
body{
  background-size: cover; 
}
span{
  font-size:15px;
}
.box{
  padding:60px 0px;
}
.box-part{
  background:#FFF;
  border-radius:0;
  padding:60px 10px;
  margin:30px 0px;
  border-radius: 60px;
}
.text{
  text-align: center;
  margin:20px 0px;
}
.fa{
 color:#4183D7;
}
#txt{
  color: black;
}
#xyz{
  border-radius: 37px;
  background-color: lightblue;
  overflow: hidden;
}
#ctc{
  border-radius: 7px;
  padding: 7px;
}
.form-group{
  margin-left: 20px;
  border-radius: 15px;
}
#sch{
  float: right;
  margin-top: 7px;
  margin-right: 9px;
  box-shadow: 0 0 .5px .5px #00000096;
}
#snackbar {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background-color: lightblue; /* Blue background color */
  color: black; /* blck text color */
  text-align: center; /* Centered text */
  border-radius: 5px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 1; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  bottom: 30px; /* 30px from the bottom */
  box-shadow: 0 0 .5px .5px #00000096;
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#snackbar.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
  from {bottom: 0; opacity: 0;}
  to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
  from {bottom: 30px; opacity: 1;}
  to {bottom: 0; opacity: 0;}
}
</style>
</head>
<body background="prj-body-bg.jpg">  
  <div class="bg-img">
    <div class="full-size-container">
      <div class="topnav " style="display: block;">
        <a href="prj-home.php">SIES BANK</a>
        <a href="http://www.siesgst.edu.in/">SIESGST Portal</a>
        <script async src="https://cse.google.com/cse.js?cx=011206658419054800993:1mitngfrgxb"></script>
        <div class="gcse-search"></div>
      </div>
    </div>
  </div>
  <div class="box" >
    <div class="container">
      <div class="jumbotron">
        <img src="prj-gst-logo.png" id="imgg" >
        <div class="title">
          <h3 id="txt"> Money Transfer </h3>
          <h4> Transfer Money from One account to another. </h4>
        </div> <br>
        <div class="container" id="xyz" style="box-shadow: 0 0 .5px .5px #00000096;"> <br>
          <h3>Tranfer money successfully in just a few steps ! </h3> <br>
          <form role="form" method="POST" id="reused_form">
            <div class="row">
              <div class="form-group">
                <label for="name"><i>Enter Your PRN :</i></label>
                <input type="text" class="form-control" id="uprn" name="uprn" placeholder="Enter Your PRN" style="box-shadow:0 0 .5px .5px #00000096; " required>
              </div>
              <div class="form-group">
                <label for="email"><i>Enter Beneficiary PRN :</i></label>
                <input type="text" class="form-control" id="bprn" name="bprn" placeholder="Enter Beneficiary PRN" style="box-shadow:0 0 .5px .5px #00000096; " required>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <label for="email"><i> Message:</i></label>
                <input type="text" class="form-control" id="mess" name="mess" placeholder="Enter Small Message" style="box-shadow:0 0 .5px .5px #00000096; " required>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <label for="email"><i> Enter Amount:</i></label>
                <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter Amount" style="box-shadow:0 0 .5px .5px #00000096; " required>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <button type="submit" class="btn btn-success pull-right" style="box-shadow:0 0 .5px .5px #00000096; " name="transfer" > Transfer </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
            <div id="snackbar" style="width:100%; height:100%; display:none; "> <h3>Tranfered successfully!</h3> </div>
  <footer class="page-footer font-small stylish-color-dark " id="footer" >
    <div class="full-size-container">
      <hr class="footer w-100 d-md-none">
      <div class="col-md-2"><br>
        <h5 class="font-weight-bold text-uppercase mt-3 mb-4"> Navigate</h5>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="prj-privacy.html"> Privacy Policy </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="prj-about.html"> About Us </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="prj-contact.html"> Contact Us </a>
          </li>
        </ul>
      </div>
    </div>
  </footer>
<?php

      if (!isset($_GET['signup'])) {
        exit();
      }
      else
      {

        $check = $_GET['signup'];
        if ($check == "empty") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("You did not fill in all the details")'; 
          echo '</script>';
          exit();
        }
        if ($check == "lessamount") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Amount is less in Your Account For Transfer")'; 
          echo '</script>';
          exit();
        }
        if ($check == "invalid") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Enter Your Valid PRN")'; 
          echo '</script>';
          exit();
        }
        if ($check == "notex") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Entered Beneficiary PRN Does not Exist. Enter Valid Prn!!")'; 
          echo '</script>';
          exit();
        }
        if($check == "success"){
        echo '<script>';
        echo 'var x = document.getElementById("snackbar");';
        echo 'x.className = "show";';
        echo 'setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);';
        echo '</script>';
      } 
      }
      ?>
</body>
</html>
