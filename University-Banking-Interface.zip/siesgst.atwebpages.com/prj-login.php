<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SIESGST Bank</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">
    @import url('https://fonts.googleapis.com/css?family=Mukta');
    body{
      font-family: 'Mukta', sans-serif;
      height:100vh;
      min-height:550px;
      background-repeat: no-repeat;
      background-size:cover;
      background-position:center;
      position:relative;
      overflow-y: auto;
    }
    a{
      text-decoration:none;
      color:#444444;
    }
    .login-reg-panel{
      position: relative;
      top: 50%;
      transform: translateY(-50%);
      text-align:center;
      width:70%;
      right:0;left:0;
      margin:auto;
      height:400px;
      background-color: rgba(236, 48, 20, 0.9);
    }
    .white-panel{
      background-color: rgba(255,255, 255, 1);
      height:500px;
      position:absolute;
      top:-50px;
      width:50%;
      right:calc(50% - 50px);
      transition:.3s ease-in-out;
      z-index:0;
      box-shadow: 0 0 15px 9px #00000096;
    }
    .login-reg-panel input[type="radio"]{
      position:relative;
      display:none;
    }
    .login-reg-panel{
      color:#B8B8B8;
    }
    .login-reg-panel #label-login, 
    .login-reg-panel #label-register{
      border:1px solid #9E9E9E;
      padding:5px 5px;
      width:150px;
      display:block;
      text-align:center;
      border-radius:10px;
      cursor:pointer;
      font-weight: 600;
      font-size: 18px;
    }
    .login-info-box{
      width:30%;
      padding:0 50px;
      top:20%;
      left:0;
      position:absolute;
      text-align:left;
    }
    .register-info-box{
      width:30%;
      padding:0 10px;
      top:10%;
      right:0;
      position:absolute;
      text-align:left;

    }
    .right-log{right:50px !important;}

    .login-show, 
    .register-show{
      z-index: 1;
      display:none;
      opacity:0;
      transition:0.3s ease-in-out;
      color:#242424;
      text-align:left;
      padding:50px;
    }
    .show-log-panel{
      display:block;
      opacity:0.9;
    }
    .login-show input[type="text"], .login-show input[type="password"]{
      width: 100%;
      display: block;
      margin:20px 0;
      padding: 15px;
      border: 1px solid #b5b5b5;
      outline: none;
      style="box-shadow:0 0 .5px .5px #00000096; "
    }
    .login-show input[type="submit"] {
      max-width: 150px;
      width: 100%;
      background: #444444;
      color: #f9f9f9;
      border: none;
      padding: 10px;
      text-transform: uppercase;
      border-radius: 2px;
      float:right;
      cursor:pointer;
    }
    .login-show a{
      display:inline-block;
      padding:10px 0;
      }/* width */
      ::-webkit-scrollbar {
        width: 20px;
      }

      /* Track */
      ::-webkit-scrollbar-track {
        box-shadow: inset 0 0.5px 5px #0333; 
        border-radius: 8px;
      }
      
      /* Handle */
      ::-webkit-scrollbar-thumb {
        background: lightgrey; 
        border-radius: 8px;
      }

      /* Handle on hover */
      ::-webkit-scrollbar-thumb:hover {
        background: lightblue; 
      }

      .register-show input[type="text"], .register-show input[type="password"]{
        width: 100%;
        display: block;
        margin:20px 0;
        padding: 15px;
        border: 1px solid #b5b5b5;
        outline: none;
        style="box-shadow:0 0 .5px .5px #00000096; "
      }
      .register-show input[type="submit"] {
        max-width: 150px;
        width: 100%;
        background: #444444;
        color: #f9f9f9;
        border: none;
        padding: 10px;
        text-transform: uppercase;
        border-radius: 2px;
        float:right;
        cursor:pointer;
      }
      a{
        text-decoration:none;
        color:#2c7715;
      }
      #igst{
        margin-top: 10px;
        top: 90%;
        border-radius: 3px;
        box-shadow:1 0 .5px .5px #00000096;
      }
      .topnav {
        box-shadow: 0 0 15px 9px #00000096;
        overflow: hidden;
        background-color: rgba(236, 48, 20, 0.9);
      }

      .topnav a {
        float: left;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-size: 15px;
      }

      .topnav a:hover {
        transition: all 0.4s ease;
        background-color: #ffffff;
        color: black;transform: scale(1.1);
      }
      #logg{
        display: flex;
        flex-wrap: wrap-reverse;
        flex-flow: row wrap;
      }
      #sch{
        float: right;
        margin-top: 10px;
        margin-right: 9px;
        box-shadow: 0 0 .5px .5px #00000096;

      }
      @media (max-width: 768px) {
        .btn btn-danger {
         padding:2px 4px;
         font-size:80%;
         line-height: 1;
       }
     }

     #snackbar {
      visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background-color: lightblue; /* Blue background color */
  color: black; /* blck text color */
  text-align: center; /* Centered text */
  border-radius: 5px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 1; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  bottom: 30px; /* 30px from the bottom */
  box-shadow: 0 0 .5px .5px #00000096;
    }

    #snackbar.show {
      visibility: visible;
      -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
      animation: fadein 0.5s, fadeout 0.5s 2.5s;
    }

    @-webkit-keyframes fadein {
      from {bottom: 0; opacity: 0;} 
      to {bottom: 30px; opacity: 1;}
    }

    @keyframes fadein {
      from {bottom: 0; opacity: 0;}
      to {bottom: 30px; opacity: 1;}
    }

    @-webkit-keyframes fadeout {
      from {bottom: 30px; opacity: 1;} 
      to {bottom: 0; opacity: 0;}
    }

    @keyframes fadeout {
      from {bottom: 30px; opacity: 1;}
      to {bottom: 0; opacity: 0;}
    }
    @media only screen and (max-width: 600px){
      .login-reg-panel{width: 95%;
      }
      .white-panel{width: 60%;right:calc(50% - 60px);height: 450px;
      }

      .login-info-box{padding: 0 10px;}
      #login-register{
        width: 70px;
      }
      .login-show,.register-show{
        padding: 5px;
      }
      .login-show input[type="text"], .login-show input[type="password"]{
        margin: 10px 5px;
      }
      .register-show input[type="text"], .register-show input[type="password"]{
        margin: 10px 5px;
      }
      .login-show input[type="submit"] { margin-bottom:20px;}
      .topnav a { padding: 10px 12px; }
      .right-log{right:10px !important;}

    }
  </style>
  <body background="prj-body-bg.jpg">
    <div class="bg-img">
      <div class="full-size-container">
        <div class="topnav" style="display: block;">
          <a href="prj-home.php">SIES BANK</a>
                         <script async src="https://cse.google.com/cse.js?cx=011206658419054800993:1mitngfrgxb"></script>
<div class="gcse-search"></div>
        </div>
      </div>
    </div>
    <div class="login-reg-panel" id="logg" style="box-shadow: 0 0 2px 2px #00000096;">
      <div class="login-info-box col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <h3>  Press Below  </h3>
        <label id="label-register" for="log-reg-show" class="btn btn-outline-success"> Login </label>
        <input type="radio" name="active-log-panel" id="log-reg-show"  checked="checked">
      </div>

      <div class="register-info-box col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <h3>Don't have an account ?</h3>
        <label id="label-login" for="log-login-show" class="btn btn-outline-success" > Register</label>
        <input type="radio" name="active-log-panel" id="log-login-show">
        <a href="prj-home.html" >
          <img src="prj-gst-logo.png" class="col-lg-12 col-md-4 col-sm-4 col-xs-12" id="igst" style="box-shadow:0 0 .5px .5px #00000096; ">
        </a>
      </div>              
      <div class="white-panel col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <form name="LogF" action="" method="post">
          <div class="login-show">
            <h2> LOGIN </h2>
            <input type="text" placeholder="Enter PRN" name="username"  required >
            <input type="password" name="password" pattern=".{8,}" id="myInput" required title="8 characters minimum" placeholder="Enter Password"  required>
            <input type="submit" class="btn btn-danger" value="Login" name=login_user> <br>   
            <input type="checkbox" onclick="myFunction()"> Show Password<br>    <br><br>
            <a href="prj-forgotpw.html">Forgot password ?</a>
          </div>
        </form>
        <form name="RegF" id="reg-form" action="prj-login.php" method="post">
          <div class="register-show" >
            <h2> Create Account </h2>
            <input type="text" placeholder="Enter PRN"  name="username1">
            <input type="text" placeholder="Enter Email" name="email">
            <input type="password" pattern=".{8,}"  required title="8 characters minimum" placeholder="Enter Strong Password" name="password_1" >
            <input type="password" pattern=".{8,}"  required title="8 characters minimum" placeholder="Confirm Password" name="password_2">
            <div class="checkbox">
              <label><input type="checkbox" name="remember">Remember me</label>
            </div>
            <input type="submit" value="Register"  class="btn btn-danger" name="reg_user">
          </div>
        </form>
      </div>
    </div>

    <script type="text/javascript">
      function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
      }
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
        $('.login-info-box').fadeOut();
        $('.login-show').addClass('show-log-panel');
      });
      $('.login-reg-panel input[type="radio"]').on('change', function() {
        if($('#log-login-show').is(':checked')) {
          $('.register-info-box').fadeOut(); 
          $('.login-info-box').fadeIn();   
          $('.white-panel').addClass('right-log');
          $('.register-show').addClass('show-log-panel');
          $('.login-show').removeClass('show-log-panel');    
        }
        else if($('#log-reg-show').is(':checked')) {
          $('.register-info-box').fadeIn();
          $('.login-info-box').fadeOut();

          $('.white-panel').removeClass('right-log');

          $('.login-show').addClass('show-log-panel');
          $('.register-show').removeClass('show-log-panel');
        }
      });
    </script>
    <div id="snackbar">Account Created Successfully </div>
      <?php

      if (!isset($_GET['signup'])) {
        exit();
      }
      else
      {

        $check = $_GET['signup'];
        if ($check == "empty") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("You did not fill in all the details")'; 
          echo '</script>';
          exit();
        }
        if ($check == "email") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Email is invalid")'; 
          echo '</script>';
          exit();
        }
        if ($check == "pass") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Fill the same password in both fields")'; 
          echo '</script>';
          exit();
        }
        if ($check == "uexist") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("PRN already Exists")'; 
          echo '</script>';
          exit();
        }
        if ($check == "eexist") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Email already Exists")'; 
          echo '</script>';
          exit();
        }
        if ($check == "not") 
        {
          echo '<script type="text/javascript">';
          echo ' alert("Wrong username/password combination")'; 
          echo '</script>';
          exit();
        }
        if($check == "success"){
        echo '<script>';
        echo 'var x = document.getElementById("snackbar");';
        echo 'x.className = "show";';
        echo 'setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);';
        echo '</script>';
      } 
      }
      ?>
      </body>
      </head>
      </html>




