<?php
include('session.php');

if (isset($_POST['transfer'])) {

 include_once 'config.php'; 
  // receive all input values from the form
$uprn  =  $_POST['uprn'];
$bprn  =  $_POST['bprn'];
$amount  =  $_POST['amount'];

$a ="SELECT * FROM $uprn ORDER BY id DESC LIMIT 1;";
$aa=mysqli_query($db, $a);
$a1 = mysqli_fetch_assoc($aa);

$check="SELECT * FROM reg WHERE prn = '$bprn'";
    $result = mysqli_query($db,$check);

    if(mysqli_num_rows($result) > 0)
    { $user=true;
    }
    else
    { $user=false;
    }

 if(empty($uprn) || empty($bprn) ||empty($amount)) {
  header("./prj-der.php?signup=empty");
  exit();
}
elseif($amount > $a1['total'])
{header("Location: ./prj-der.php?signup=lessamount");
  exit();
}
else{
  if($uprn != $code )
  {
    header("Location: ./prj-der.php?signup=invalid");
    exit();
  }
  elseif ($user == false) {
    header("Location: ./prj-der.php?signup=notex");
    exit();
  }
  else{
    $a1['total']=$a1['total']-$amount;
    
    $uu= "INSERT INTO $uprn (deposit, withdrawal, total) VALUES('0','$amount','".$a1['total']."')";
    mysqli_query($db, $uu);
    
    $b ="SELECT * FROM $bprn ORDER BY id DESC LIMIT 1;";
    $bb= mysqli_query($db, $b);
    $b1 = mysqli_fetch_assoc($bb);
    
    $b1['total']=$b1['total']+$amount;
    $yy= "INSERT INTO $bprn (deposit, withdrawal, total) VALUES('$amount','0','".$b1['total']."')";
    mysqli_query($db, $yy);
    
    header('location: ./prj-der.php?signup=success');
  }
}
}
?>
